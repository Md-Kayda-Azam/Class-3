

for(let i= 1; i <=1000; i += 3){
           console.log(i);
           if( i % 11 ==0){
               break;
           }
    }
