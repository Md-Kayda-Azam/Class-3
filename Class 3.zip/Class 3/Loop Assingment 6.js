


for(let i =9950; i <= 10000; i++){
    console.log(i);

    if( i == 10000 )
    for( let a=10000; a >= 9950; a--){
        console.log(a);
    }
}